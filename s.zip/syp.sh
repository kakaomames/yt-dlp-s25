#!/bin/bash

# ========================================================
# Gemini programming隊特製: トンネル起動 ＆ URL自動Git Pushスクリプト (強制特攻版)
# ========================================================
rm -f s.zip
zip -r s.zip ./*.py ./*.sh ./*.txt

echo "[LOG] SYSTEM: 復活ミッション（GitHub連携・強制特攻ルート）を開始します！"
# 1. サーバーの幽霊を退治して再起動
pkill -f server.py
pkill -f "ssh -R 80:localhost:9080"  # 👈 🛑【真・ゾンビ絶対殺すコマンド】これで連続起動も100%安全！

echo "止める"
rm -rf /storage/emulated/0/yt-dlp-Xiaomi/.git/index.lock

# 🛑【バグ修正】もしPython側からトークンが渡ってきていなかった場合だけ、保険でファイルから読み込む
if [ -z "$GITPAD" ]; then
    GITPAD=$(cat file.txt)
fi

git remote set-url origin https://github.com/kakaomames/yt-dlp-s25.git

git config --global user.email "kakaomames@example.com"
git config --global user.name "kakaomames"
# 最新情報を取得
git fetch origin

rm -fr ./tunnel_output.log
echo " " > tunnel_output.log

Log() {
    local time=$(date +"%H:%M:%S")
    echo "[$time] $1"
}

# 3. 主軸ブランチの名前を確実に「main」に設定
git branch -M main

# 4. 変更があったらログに出すため、現在の接続先を画面に表示して確認！
git remote -v

sleep 1
echo "[LOG] ACTION: server.py を裏側で起動中..."
python3 server.py > server.log 2>&1 &
sleep 2

# 2. トンネルの一時ログファイルをリセット
TUNNEL_LOG="tunnel_output.log"
> $TUNNEL_LOG

# 3. localhost.run のトンネルを裏で起動し、ログを書き出す
echo "[LOG] ACTION: SSHを使って世界へのトンネルを開通します..."
ssh -R 80:localhost:9080 nokey@localhost.run > $TUNNEL_LOG 2>&1 &


echo "=============================="

echo "[LOG] ACTION: トンネルのURL発行を常時監視しています..."

# 4. ログをループで監視して、URLが見つかるまで待機・更新し続ける
while true; do
    # ログから最新のURL（.lhr.life または .localhost.run）を抽出
    LATEST_URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.(lhr\.life)" $TUNNEL_LOG | tail -n 1)
    
    if [ ! -z "$LATEST_URL" ]; then
        # 前回保存したURLと比較するために、現在のファイルの中身を読み込む
        OLD_URL=""
        if [ -f urls.json ]; then
            OLD_URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.(lhr\.life|localhost\.run)" urls.json)
        fi
        
        # 値が変わったときだけログに出して GitHub にプッシュする！
        if [ "$LATEST_URL" != "$OLD_URL" ]; then
            echo "[LOG] SUCCESS: 新しいプロキシURLを検知しました！ -> $LATEST_URL"
            
            # JSONを作成
            echo "{\"proxy_url\": \"$LATEST_URL\"}" > urls.json
            echo "[LOG] ACTION: urls.json の値を更新しました。"
            echo "{\"proxy_url\": \"$LATEST_URL\"}" > url.json
            echo "[LOG] ACTION: url.json の値を更新しました。"
            rm -r ./tunnel_output.log
            echo " " > tunnel_output.log
            
            # ギット コマンドで強制プッシュ（--force）し続ける！
            echo "[LOG] ACTION: GitHubへ最新URLを強制プッシュ（--force）します..."
            rm -rf .git/index.lock
            git add ./*.json
            git add ./*.py
            git add ./*.zip
            git commit -m "UPDATE: Current proxy URL to $LATEST_URL" || true
            
            # 🌟 Pythonから確実に引き継いだ環境変数 $GITPAD を使って物理破壊プッシュ！
            git push https://$GITPAD@github.com/kakaomames/yt-dlp-s25.git main --force
            
            Log "[LOG] SUCCESS: GitHubへの同期が100%完了しました！"
        fi
    fi
    
    # whileループの「中」で確実に毎秒1秒止まる安心設計
    sleep 1
done
